declare namespace _default {

	export const lights_fragment_begin: string;
	export const lights_pars_begin: string;

}

export default _default;
